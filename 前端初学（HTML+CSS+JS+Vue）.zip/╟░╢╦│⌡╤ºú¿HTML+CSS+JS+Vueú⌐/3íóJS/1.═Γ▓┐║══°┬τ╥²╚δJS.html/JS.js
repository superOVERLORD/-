var num = 20;
console.log(num);