<template>
    <h2>组件传递数据_props</h2>
    <h3>Parent</h3>
    <Child :title="message" :users="userInfo"/>
</template>
<script>
import Child from "./2.Child.vue";
export default {
    data(){
        return{
            message:"Parent数据",
            userInfo:{
                name:"李四",
                age:20,
            }
        }
    },
    components:{
        Child
    }
}
</script>