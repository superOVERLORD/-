<template>
    <h3>Child</h3>
    <p>{{ title }}</p>
    <p>{{ users.name }}</p>
    <p>{{ users.age }}</p>
</template>
<script>
export default {
    data() {
        return {

        }
    },
    props:["title","users"]
}
</script>