<template>
   <h3>ComponentsB</h3>
   <p>{{ title }}</p>
   <p>{{ age }}</p>
   <p v-for="(item, index) of names" :key="index">{{ item }}</p>
</template>
<script>
export default {
    data() {
        return {
          
        }
    },
    props:{
        title:{
            type:String,
            //必选项
            required:true
        },
        age:{
            type:Number,
            default:18,
        },
        names:{
           type:Array,
           default(){
            return ["空"]
           }
        }
    }
}
</script>