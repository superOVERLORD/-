<template>
    <h2>组件传递效验及默认值</h2>
    <h3>ComponentsA</h3>
    <ComponentsB :title="title"/>
</template>
<script>
import ComponentsB from "./2.2ComponentsB.vue";
export default {
    data() {
        return {
            title: "itbaizhan",
            age: 20,
            names: ["ia", "ib"]
        }
    },
    components: {
        ComponentsB
    }
}
</script>