import { createApp } from 'vue'
import App from './App.vue'

const app = createApp(App);
//在中间写组件注册(全局注册)
app.component("",);

app.mount('#app');
