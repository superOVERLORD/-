<template>
    <!-- <Parent /> -->
    <ComponentsA/>
</template>
<script>
// import Parent from "./components/1.parent.vue";
import ComponentsA from "./components/2.1ComponentsA.vue";
export default {
    data(){
        return{

        }
    },
    components:{
        // Parent
        ComponentsA
    }
}
</script>
<style></style>