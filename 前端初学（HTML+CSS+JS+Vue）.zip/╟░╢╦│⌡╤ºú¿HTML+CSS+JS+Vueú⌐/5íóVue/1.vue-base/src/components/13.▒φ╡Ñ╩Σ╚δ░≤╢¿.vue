<template>
    <h3>表单输入绑定</h3>
    <form action="">
        <!-- .lazy修改为事件change后更新数据 -->
        <input type="text" v-model.lazy="message1">
        <p>{{ message1 }}</p>
        <!-- .number修改为只接受数字 -->
        <input type="text" v-model.number="message2">
        <p>{{ message2 }}</p>
    </form>
</template>
<script>
export default {
    data() {
        return {
            message1:"",
            message2:"",
        }
    }
}
</script>
