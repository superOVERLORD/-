<template>
    <h3>方法事件处理器</h3>
    <!-- @即v-on: -->
    <button @click="addCount">Add++</button>
    <p>{{ count }}</p>
</template>
<script>
export default {
    data() {
        return {
            count: 0,
        }
    },
    methods: {
        addCount() {
            this.count++;
        }
    }
}
</script>
