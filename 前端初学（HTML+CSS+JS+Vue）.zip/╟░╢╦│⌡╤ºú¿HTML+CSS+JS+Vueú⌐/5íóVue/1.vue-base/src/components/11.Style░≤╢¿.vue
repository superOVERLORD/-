<template>
    <p :style="styleObject">Style样式绑定</p>
</template>
<script>
export default {
    data() {
        return {
            styleObject:{
                color:"red",
                fontSize:"50px",
            }
        }
    }
}
</script>
