<template>
    <h3>内联事件处理器</h3>
    <!-- @即v-on: -->
    <button @click="count++">Add++</button>
    <p>{{ count }}</p>
</template>
<script>
export default {
    data() {
        return {
            count: 0,
        }
    }
}
</script>
