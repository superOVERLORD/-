<template>
    <h3>条件渲染</h3>
    <div v-if="flag === 'A'">true</div>
    <div v-else-if="flag === 'B'">false</div>
    <div v-else-if="flag === 'C'">null</div>
    <div v-else>?</div>
    <!-- v-show不论是否为true都会渲染（有个display开关），而v-if为false时不会进行渲染 -->
    <div v-show="NO === undefined">NO</div>
</template>
<script>
export default {
    data() {
        return {
            flag: 'B',
            NO:undefined,
        }
    }
}
</script>