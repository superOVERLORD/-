<template>
    <div>
        <h3>数组1</h3>
        <p v-for="(item,index) of nums1" :key="index">{{ item }}</p>
        <h3>数组2</h3>
        <p v-for="(item,index) of nums2" :key="index">{{ item }}</p>
        <button @click="filterHandle">合并为新数组</button>
        <h3>{{ title }}</h3>
        <p v-for="(item,index) of nums3" :key="index">{{ item }}</p>
    </div>
</template>
<script>
export default {
    data() {
        return {
            nums1:[1,2,3,4,5],
            nums2:[6,7,8,9,10],
            nums3:[],
            id:"filter",
            title:"",
        }
    },
    methods:{
        filterHandle(){
            this.title = "数组3";
            this.nums3 = this.nums1.concat(this.nums2);
        }
    }
}
</script>
