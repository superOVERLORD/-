<template>
    <h3>{{ itbaizhan.name }}</h3>
    <p>{{ itbaizhanContent1 }}</p>
    <p>{{ itbaizhanContent2() }}</p>
</template>
<script>
export default {
    data() {
        return {
            itbaizhan:{
                name:"百战程序员",
                content:["2","1","3"],
            }
        }
    },
    //计算属性：相较于方法，它可以优化性能
    computed:{
        itbaizhanContent1(){
            return this.itbaizhan.content.length > 0 ? "Yes" : "No";
        }
    },
    //函数
    methods:{
        itbaizhanContent2(){
            return this.itbaizhan.content.length > 0 ? "Yes" : "No";
        }
    }
}
</script>
