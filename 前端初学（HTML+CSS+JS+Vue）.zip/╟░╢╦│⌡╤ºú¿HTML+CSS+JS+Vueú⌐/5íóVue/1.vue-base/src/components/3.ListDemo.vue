<template>
    <h3>列表渲染</h3>
    <div v-for="item of nav">{{ item }}</div>
    <div :class="container" v-for="item of result" :key="item.id">
        <p :clsss="text">{{ item.title }}</p>
        <img :class="box" :src="item.avator" alt="图片加载失败">
    </div>
    <div v-for="{ item, key, index } of user">{{ item, key, index }}</div>
</template>
<script>
export default {
    data() {
        return {
            nav: ["手机", "家电", "平板", "电脑"],
            result: [
                {
                    "id": "202110",
                    "title": "dog",
                    "avator": "https://img.zcool.cn/community/01d89d556899f60000012716e4364f.jpg@1280w_1l_2o_100sh.jpg",
                },
                {
                    "id": "202113",
                    "title": "cat",
                    "avator": "https://tse3-mm.cn.bing.net/th/id/OIP-C.Zte3ljd4g6kqrWWyg-8fhAHaEo?rs=1&pid=ImgDetMain",
                },
                {
                    "id": "202126",
                    "title": "beauty",
                    "avator": "https://tse2-mm.cn.bing.net/th/id/OIP-C.pZHL7DCDmur3fga82E-J-gHaNK?rs=1&pid=ImgDetMain",
                },
            ],
            user: {
                name: "person",
                age: 10,
                sex: "male",
            },
            box: "box",
            text: "text",
            container: "container",
        }
    }
}
</script>
<style>
.contianer {
    display: flex;
}

.box {
    width: 474px;
}

.text {
    color: aquamarine;
}
</style>