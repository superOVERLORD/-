<template>
    <p :class="{'active':isActive, 'text-danger':hasError}">Class样式绑定1</p>
    <p :class="ClassObject">Class样式绑定2</p>
    <p :class="[arrActive,arrHasError]">Class样式绑定3</p>
</template>
<script>
export default {
    data() {
        return {
            //单个对象
            isActive:true,
            hasError:false,
            //多个对象
            ClassObject:{
                'active':true,
                'text-danger':false,
            },
            //数组
            arrActive:"active",
            arrHasError:"text-danger",
        }
    }
}
</script>
<style>
.active{
    color:red;
    font-size:50px;
}
.text-danger{
    color:blue;
    font-weight: 900;
}
</style>
