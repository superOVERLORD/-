<template>
    <h3>事件参数处理器</h3>
    <!-- @即v-on: -->
    <button @click="addCount">Add++</button>
    <p @click="getName(item)" v-for="(item,index) of names" :key="index">{{ item }}</p>
</template>
<script>
export default {
    data() {
        return {
            count: 1,
            names:["ia","ib","ic"],
        }
    },
    methods: {
        addCount(e) {
            e.target.innerHTML = "Add" + this.count++;
        },
        getName(name){
            console.log(name);
        }
    }
}
</script>
