<template>
    <h3>事件修饰符</h3>
    <!-- 使用.prevent替代e.preventDefault() -->
    <a href="https://itbaizhan.com" @click.prevent="clickHandle">百战程序员</a>
</template>
<script>
export default {
    date() {
        return {

        }
    },
    methods:{
        clickHandle(e){
            //阻止默认事件
            //e.preventDefault();
            console.log("已点击");
        }
    }
}
</script>
