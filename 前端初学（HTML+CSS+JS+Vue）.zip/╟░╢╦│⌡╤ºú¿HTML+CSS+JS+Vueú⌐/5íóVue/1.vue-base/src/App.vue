<script setup>
import HelloWorld from './components/1.HelloWorld.vue'
import IfDemo from "./components/2.IfDemo.vue"
import ListDemo from "./components/3.ListDemo.vue"
import InEventDemo from "./components/4.内联事件处理器.vue"
import MethodEventDemo from "./components/5.方法事件处理器.vue"
import EventPara from "./components/6.事件参数.vue"
import EventModify from "./components/7.事件修饰符.vue"
import ArrayChange from "./components/8.数组变化侦测.vue"
import ComputeAttribute from "./components/9.计算属性.vue"
import ClassStyle from "./components/10.Class绑定.vue"
import SStyle from "./components/11.Style绑定.vue"
import WatchDemo from "./components/12.侦听器.vue"
import ModelDemo from "./components/13.表单输入绑定.vue"
import ModelLead from "./components/14.模板引用.vue"
</script>
<template>
      <!-- <HelloWorld/>
      <IfDemo />
      <ListDemo/> -->
      <!-- <InEventDemo />
      <MethodEventDemo />
      <EventPara/>
      <EventModify/> -->
      <!-- <ArrayChange /> -->
      <!-- <ComputeAttribute /> -->
      <!-- <ClassStyle/> -->
      <!-- <SStyle /> -->
      <!-- <WatchDemo/> -->
      <!-- <ModelDemo/> -->
      <ModelLead/>
</template>
